/** Created by Paul Serwotka on 11/15/2019
* This is the header file for the Token class. It contains the declaration for all 
* its members and methods.
*/
#pragma once
#include <string>

struct Token
{
	/**Tag used to differentiate operators from numbers
	*/
	enum Tag
	{	
		NUL, 
		NUM, 
		OP 
	};
	/**Enum used to classify non-numeric tokens
    */
	enum Op
	{
		ADD,
		SUB,
		MUL,
		DIV,
		OPEN,
		CLOSE
	};
	/**Union used as primary container for generic token
	*/
	union T
	{
		double   value;
		Op       op;
	};

	Tag      tag;
	T		 t;

	/**Standard constructor
	*/
	Token()
	{}

	/**Standard destructor
	*/
	~Token()
	{}

	Token(std::string s)
	{	/*Overloaded constructor to separate nnumeric and non-numeric terms*/
		if (strcmp(s.c_str(), "+") == 0)
		{
			tag = OP;
			t.op = ADD;
		}
		else if (strcmp(s.c_str(), "-") == 0)
		{
			tag = OP;
			t.op = SUB;
		}
		else if (strcmp(s.c_str(), "*") == 0)
		{
			tag = OP;
			t.op = MUL;
		}
		else if (strcmp(s.c_str(), "/") == 0)
		{
			tag = OP;
			t.op = DIV;
		}
		else if (strcmp(s.c_str(), "(") == 0)
		{
			tag = OP;
			t.op = OPEN;
		}
		else if (strcmp(s.c_str(), ")") == 0)
		{
			tag = OP;
			t.op = CLOSE;
		}
		
		else //Contain value for numeric terms as well
		{
			tag = NUM;
			t.value = atoi(s.data());
		}
	}
	/**Overloaded constructor for raw numeric data
	*/
	Token(double val)
	{	
		tag = NUM;
		t.value = val;
	}
	/**Copy constructor
    */
	Token(const Token& aToken)
	{
		tag = aToken.tag;
		if (tag == 1)
		{
			t.value = aToken.t.value;
		}
		else if (tag == 2)
		{
			t.op = aToken.t.op;
		}
	}
	/**Copy assignment operator overload
	*/
	Token& operator=(const Token& aToken)
	{
		this->tag = aToken.tag;
		if (tag == 1)
		{
			this->t.value = aToken.t.value;
		}
		else if (tag == 2)
		{
			this->t.op = aToken.t.op;
		}

		return *this;
	}
};