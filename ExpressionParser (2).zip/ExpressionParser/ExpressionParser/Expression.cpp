/** Created by Paul Serwotka on 11/15/2019
* This is the implementation file for the Expression class. It contains the implementation for all 
* its members and methods.
*/
#include "Expression.h"

std::vector<Token> split(const std::string& s, char delimiter)
{
	std::vector<Token> tokens;
	std::string token;
	std::istringstream tokenStream(s);
	while (std::getline(tokenStream, token, delimiter))
	{
		tokens.emplace_back(token);
	}
	return tokens;
}

/**Default constructor
*/
Expression::Expression()
{}

/**Custom constructor
*/
Expression::Expression(const std::string aExpr) 
	: expr(aExpr)
{
	tokens = split(expr, ' ');
}

/**Standard destructor
*/
Expression::~Expression()
{
}

/**Copy constructor
*/
Expression::Expression(const Expression& aExpr)
{
	expr = aExpr.getExpr();
	this->tokens = aExpr.getTokens();
}

/**Accessor method that returns the expression as a string
*/
std::string Expression::getExpr() const
{
	return expr;
}

/**Accessor method that returns the expression as a vector of tokens
*/
std::vector<Token> Expression::getTokens() const
{
	return tokens;
}

/**Copy assignment operator overload
*/
Expression& Expression::operator=(const Expression& aExpr)
{
	this->expr = aExpr.getExpr();
	this->tokens = aExpr.getTokens();

	return *this;
}

/**Helper function that validates operators and paranthesis
*/
bool Expression::isOp(const char aChar)
{
	return (aChar == '+' ||
			aChar == '-' ||
			aChar == '*' ||
			aChar == '/' ||
			aChar == '(' ||
			aChar == ')' ||
			aChar == ' ');
}

/**Function to make sure only valid expressions are entered. 
*Returns false if any invalid tokens are discovered, otherwise returns true
*/
bool Expression::validate()
{
	/**Make sure expression does not start with a wrong operator
	*/
	if (tokens.front().tag == 2 && tokens.front().t.op != 4)	//expression cannot start with an op that isn't an opening paranthesis
	{
		std::cout << "Expression invalid: cannot start with an operator\n";
		return false;
	}

	/**Make sure expression does not end with a wrong operator
	*/
	if (tokens.back().tag == 2 && tokens.back().t.op != 5)	//expression cannot start with an op that isn't an opening paranthesis
	{
		std::cout << "Expression invalid: cannot end with an operator\n";
		return false;
	}

	/**Ensure only proper tokens are being used
	*/
	for (char c : expr)
	{
		if (isdigit(c) || isOp(c))
			continue;
		else
			std::cout << "Expression invalid: (" << c << ") is not recognized\n";
			return false;
	}

	/**Check for invalid syntax in expression
	*/
	int pCount = 0;
	for (int i=0;i<tokens.size()-1;i++)
	{
		if (tokens[i].tag == 1)		//Numeric token found
		{
			if (tokens[i + 1].tag == 1)	//two subsequent numbers
			{
				std::cout << "Expression invalid: syntax must be infix (i.e, 5 + 6)\n";
				return false;
			}
			if (tokens[i + 1].tag == 2 && tokens[i+1].t.op == 4)	//number next to opening paranthesis
			{
				std::cout << "Expression invalid: use * to indicate multiplication\n";
				return false;
			}
		}
		else if (tokens[i].tag == 2 && tokens[i].t.op < 4)	//If non-paranthesis operator is found
		{
			if (tokens[i + 1].tag == 2 && tokens[i + 1].t.op < 4)	//Then next term cannot be a non-paranthesis operator
			{
				std::cout << "Expression invalid: syntax must be infix (i.e, 5 + 6)\n";
				return false;
			}
		}
		/**Check for paranthesis mismatch
		*/
		else if (tokens[i].t.op == 4)	//Opening paranthesis
		{
			if (tokens[i + 1].t.op == 2 && tokens[i + 1].t.op < 4)
			{
				std::cout << "Expression invalid: expression must be infix (i.e, 5 + 6)\n";
				return false;
			}
			pCount++;
		}
		else if (tokens[i].t.op == 5)	//Closing paranthesis
		{
			if (tokens[i + 1].tag == 1 )	//Numeric token should not directly follow a closed expr
			{
				std::cout << "Expression invalid: expression must be infix (i.e, 5 + 6)\n";
				return false;
			}
			pCount--;
		}
		if (pCount < 0)
		{
			std::cout << "Expression invalid: paranthesis must match\n";
		}
	}
	return true;
}

/**This function is used to evaluate nested expressions in paranthesis. It is
* recursive to account for inner nested expressions.
*/
double Expression::filterSubExpr(std::vector<Token> aTokens, int& i)
{
	double val = 0;
	std::vector<Token> subExp;

	while (aTokens[i].tag != 2 || aTokens[i].t.op != 5)
	{	//Go through tokens until we find a closing parathesis
		if (aTokens[i].tag == 2 && aTokens[i].t.op == 4)
		{	//Recurse if we find another nested paranthesis
			i++;
			subExp.emplace_back(filterSubExpr(aTokens, i));
		}
		else
		{
			subExp.push_back(aTokens[i]);
		}
		i++;
	}
	int newI = 0;
	return evaluate(subExp, newI);	//Indirect recursion here
}

/**Expression that runs the main evaluation algorithm
*/
double Expression::evaluate(std::vector<Token> aTokens, int& i)
{
	//First course of action is to eliminate any part of expression in paranthesis
	std::vector<Token> simplifiedExpr;
	for (int j = i; j< aTokens.size(); j++)
	{
		if (aTokens[j].tag == 2 && aTokens[j].t.op == 4)
		{	//Found opening paranthesis
			j++;
			simplifiedExpr.emplace_back(filterSubExpr(aTokens, j));
			continue;
		}
		simplifiedExpr.push_back(aTokens[j]);
	}

	//Simplified expression should be free of any paranthesis, so now evaluate it like any simple expression
	//Next handle the multiplication and division	
	Token currentTok;
	std::vector<Token> as;
	
	for (int x=0; x < simplifiedExpr.size();)
	{
		currentTok = simplifiedExpr[x];
		if (currentTok.tag == 2)	//Current token is an operator
		{
			if (currentTok.t.op == 2)	//Multiply operation
			{
				Token c = as.back();
				as.pop_back();

				as.emplace_back(c.t.value * simplifiedExpr[x+1].t.value);
				x += 2;
			}
			else if (currentTok.t.op == 3)	//Divide operation
			{
				Token c = as.back();
				as.pop_back();

				as.emplace_back(c.t.value / simplifiedExpr[x + 1].t.value);
				x += 2;
			}
			else     //Lower precedence operator(add, sub)
			{
				as.emplace_back(currentTok);
				x++;
			}
		}
		else if(currentTok.tag == 1)	//Current token is a numeric term
		{
			as.emplace_back(currentTok);
			x++;
		}
	}

	//Finally handle the addition and subtraction	
	currentTok = as.front();
	for (int x = 1; x < as.size();)
	{
		if (as[x].tag == 2)	//Current token is an operator
		{
			if (as[x].t.op == 0)	//Add operation
			{
				currentTok.t.value += as[x + 1].t.value;
				x += 2;
			}
			else if (as[x].t.op == 1)	//Subtraction operation
			{
				currentTok.t.value -= as[x + 1].t.value;
				x += 2;
			}
			else //Should not be used
			{
				std::cout << "Invalid operator placement!" << std::endl;
				exit(1);
			}
		}
		else    //Current token is a numeric term
		{
			x++;
		}
	}

	return currentTok.t.value;
}
