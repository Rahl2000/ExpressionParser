﻿Created by Paul Serwotka 15 Nov 2019


This VS 2017 project is a C++ based expression parser which runs as a simple console application on a Windows desktop machine. It continually requests 
user input in the form of a space-separated arithmetic expression and provides the result until the user requests to stop. 


As requested, the program is written in an Object Oriented fashion and does not use the Shunting Yard algorithm to evaluate expressions; instead, 
it is based off of the Recursive Descent Parser, which uses multiple methods and indirect recursion to evaluate expressions that may contain one 
or more nested “sub-expressions.” The program uses only two classes:


* Token: a struct that contains a single term in an expression and self-contains the logic for determining that term’s nature. This improves code 
	 readability in the main driver class.
* Expression: a class which contains an entire expression and the logic for validating and evaluating that expression.


The completed source code and executable for this project are contained within this directory; the executable is located under Debug and can be 
run by simply double-clicking it. Some example inputs for this program that have already been tested are provided below:


5 + 6 - ( 18 * 3 + ( 5 / 6 + 3 ) )           = -46.833

( 93 / 3 ) + 7 - ( 5 + 40 / 9 )              = 28.556

( ( 96 - 32 ) * 2 ) + 41 / ( 30 + 2 )        = 129.28

( 7 + ( 9 - 4 ) / 5 + 2 ) * 4                = 40.0

( 9 - 3 * ( 70 / 7 ) ) - 10                  = -31


Included are sources that were referenced in implementing this solution:


http://web.cse.ohio-state.edu/software/2231/web-sw2/extras/slides/27.Recursive-Descent-Parsing.pdf


https://www.fluentcpp.com/2017/04/21/how-to-split-a-string-in-c/