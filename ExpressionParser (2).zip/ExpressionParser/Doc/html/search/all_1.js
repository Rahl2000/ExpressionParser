var searchData=
[
  ['close',['CLOSE',['../struct_token.html#a59d24396566459ef5a3fccac383a037da0ac54ef97bc93d2d0fb77173ab3b76c2',1,'Token']]]
];
