/** Created by Paul Serwotka on 11/15/2019
* This is the header file for the Expression class. It contains the declaration for all 
* its members and methods.
*/
#pragma once
#include "Token.h"

#include <string>
#include <vector>
#include <cctype>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <iterator>

class Expression
{
public:
	Expression();
	Expression(const Expression& aExpr);
	~Expression();

	Expression(std::string aExpr);

	bool validate();
	double evaluate(std::vector<Token> aTokens, int& i);

	std::string getExpr() const;
	std::vector<Token> getTokens() const;
	Expression& operator=(const Expression& aExpr);

private:
	std::string expr;
	std::vector<Token> tokens;

	bool isOp(const char aChar);
	double filterSubExpr(std::vector<Token> aTokens, int& i);
};

