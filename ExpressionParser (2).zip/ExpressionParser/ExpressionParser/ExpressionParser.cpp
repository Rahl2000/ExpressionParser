/** Created by Paul Serwotka on 11/15/2019
* This is the main driver file which contains the core 
* logic for the application.
*/

#include <string>
#include <iostream>

#include "Expression.h"
#include "Token.h"

int main()
{
	std::string expressionInput;
	do {		//Program runs continuously until user request to stop
		std::cout << "Please enter an arithmetic expression separated by spaces to evaluate\ni.e, 5 + 6 / ( 18 / 3 ) - 7 or q to quit\n";

		std::getline(std::cin, expressionInput);

		if (std::strcmp(expressionInput.c_str(), "q") == 0)
		{
			break;
		}

		//Construct an object based on the input
		Expression input(expressionInput);

		//Validate input for spacing and syntax
		if (!input.validate())
		{
			std::cout << "Make sure only numbers, paranthesis, and approved operators(+,-,*,/) are in use\n";
			continue;
		}

		std::cout << "Expession valid, evaluating...\n";

		//Run the input through the evaluation algorithm
		int i = 0;
		double result = input.evaluate(input.getTokens(), i);

		std::cout << "\nExpression evaluated to " << result << std::endl;

	} while (true);
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
